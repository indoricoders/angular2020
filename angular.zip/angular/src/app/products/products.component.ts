import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';


@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.css']
})
export class ProductsComponent implements OnInit {

  constructor(private router: Router ){}

  products = [
    { id: 1, name: 'angular' },
    { id: 2, name: 'java' },
    { id: 3, name: 'dotnet' },
    { id: 4, name: 'wordpress' },
    { id: 5, name: 'python' }
  ];

  onSelect(product) {
    this.router.navigate(['/products',product.id]);

  };



  ngOnInit() {
  }

}
